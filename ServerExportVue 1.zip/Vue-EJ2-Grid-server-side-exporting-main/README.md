# Vue-EJ2-Grid-server-side-exporting
This sample demonstrates how to export the EJ2 Vue Grid in server side
