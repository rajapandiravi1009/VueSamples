<template>
    <div>
        <h2>Chart</h2>
        <ejs-chart id="container" :title='title' :primaryXAxis='primaryXAxis' :primaryYAxis='primaryYAxis'
            :tooltip='tooltip' :loaded='loaded'>
            <e-series-collection>
                <e-series :dataSource='seriesData' type='Line' xName='month' yName='sales' name='Sales'
                    :marker='marker'></e-series>
            </e-series-collection>
        </ejs-chart>
    </div>
</template>
<script>
import { ChartComponent,  SeriesCollectionDirective,  SeriesDirective, LineSeries, Category, DataLabel, Tooltip } from "@syncfusion/ej2-vue-charts";

export default {
    name: "ChartComponent",
    components: {
        "ejs-chart": ChartComponent,
        "e-series": SeriesDirective,
        "e-series-collection": SeriesCollectionDirective
    },
    data() {
        return {
            seriesData: [
                { month: 'Jan', sales: 35 }, { month: 'Feb', sales: 28 },
                { month: 'Mar', sales: 34 }, { month: 'Apr', sales: 32 },
                { month: 'May', sales: 40 }, { month: 'Jun', sales: 32 },
                { month: 'Jul', sales: 35 }, { month: 'Aug', sales: 55 },
                { month: 'Sep', sales: 38 }, { month: 'Oct', sales: 30 },
                { month: 'Nov', sales: 25 }, { month: 'Dec', sales: 32 }
            ],
            primaryXAxis: { valueType: 'Category' },
            primaryYAxis: { labelFormat: '${value}K' },
            legendSettings: { visible: true }, 
            marker: { dataLabel: { visible: true } },
            tooltip: { enable: true },
            title: "Sales Analysis"
        };
    },
    provide: { chart: [LineSeries, Category, DataLabel, Tooltip] },
    methods: {
        loaded: function () { console.log('Chart created'); }
    }
};
</script>