<template>
    <div id="grid">
        <br />
        <br />
        <br />
        <ejs-grid ref="grid" :dataSource="ds" :editSettings='editSettings'>
            <e-columns>
                <e-column field="OrderID" headerText="Order ID" :isPrimaryKey='true' width=120 />
                <e-column field="CustomerID" headerText="Customer ID" width=150 />
                <e-column field="Freight" headerText="Freight" width=150  />
            </e-columns>
        </ejs-grid>
    </div>
</template>
<script>
import { GridComponent, ColumnDirective, ColumnsDirective, Edit } from "@syncfusion/ej2-vue-grids";
import { createApp } from 'vue';
import DialogTemplate from './dialog-temp.vue';

export default {
    name: "App",
    components: {
        "ejs-grid": GridComponent,
        "e-columns": ColumnsDirective,
        "e-column": ColumnDirective,
    },
    data() {
        return {
            ds: [
                { OrderID: 10248, CustomerID: 'VINET', Freight: 32.38 },
                { OrderID: 10249, CustomerID: 'TOMSP', Freight: 11.61 },
                { OrderID: 10250, CustomerID: 'HANAR', Freight: 65.83 }
            ],
            pageSettings: { pageSize: 5 },
            editSettings: {
                allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Dialog',
                template: function () {
                    return {
                        template: createApp({}).component('dialog', DialogTemplate),
                    };
                },
            }
        }
    },
    provide: { grid: [Edit] }
}
</script>