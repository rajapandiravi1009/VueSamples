<template>
  <div>
    <h2>Nuxt 3 samples</h2>
    <ul style="list-style-type:none;">
      <li><NuxtLink to="/Chart">Chart</NuxtLink></li>
      <li><NuxtLink to="/Grid">Grid</NuxtLink></li>
      <li><NuxtLink to="/Maps">Maps</NuxtLink></li>
      <li><NuxtLink to="/Form">Form</NuxtLink></li>
      <li><NuxtLink to="/TreeView">TreeView</NuxtLink></li>
    </ul>
  </div>
</template>