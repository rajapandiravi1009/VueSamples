<template>
    <div formGroup="orderForm">
      <div class="form-row">
        <div class="form-group col-md-6">
          <div class="e-float-input e-control-wrapper">
            <input
              ref="OrderID"
              id="OrderID"
              name="OrderID"
              v-model="data.OrderID"
              type="text"
              :disabled="!data.isAdd"
            />
            <span class="e-float-line"></span>
            <label class="e-float-text e-label-top" for="OrderID">
              Order ID</label
            >
          </div>
        </div>
        <div class="form-group col-md-6">
          <div class="e-float-input e-control-wrapper">
            <input
              ref="CustomerID"
              id="CustomerID"
              name="CustomerID"
              v-model="data.CustomerID"
              type="text"
            />
            <span class="e-float-line"></span>
            <label class="e-float-text e-label-top" for="CustomerID"
              >Customer Names</label
            >
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import { DataUtil } from '@syncfusion/ej2-data';
  
  export default {
    components: {

    },
    data() {
      return {
        data: {}
      };
    },
    mounted() {
      // Set initail Focus
      if (this.data.isAdd) {
        this.$refs.OrderID.focus();
      } else {
        this.$refs.CustomerID.focus();
      }
    },
  };
  </script>
  
  <style scoped>
  .form-group.col-md-6 {
    width: 250px;
  }
  #ShipAddress {
    resize: vertical;
  }
  :-ms-fullscreen,
  .e-dialog.e-edit-dialog {
    max-width: 552px;
  }
  </style>
  