// https://nuxt.com/docs/api/configuration/nuxt-config
export default {
  css: [
    "~/node_modules/@syncfusion/ej2-base/styles/material.css",
    "~/node_modules/@syncfusion/ej2-inputs/styles/material.css",
    "~/node_modules/@syncfusion/ej2-buttons/styles/material.css",
    "~/node_modules/@syncfusion/ej2-popups/styles/material.css",
    "~/node_modules/@syncfusion/ej2-splitbuttons/styles/material.css",
    "~/node_modules/@syncfusion/ej2-vue-grids/styles/material.css",
    "~/node_modules/@syncfusion/ej2-vue-navigations/styles/material.css",
    "~/node_modules/@syncfusion/ej2-vue-dropdowns/styles/material.css",
    "~/node_modules/@syncfusion/ej2-vue-buttons/styles/material.css",
    "~/node_modules/@syncfusion/ej2-vue-inputs/styles/material.css",
  ],
  vite: {
    resolve: {
      alias: {
        vue: "vue/dist/vue.esm-bundler",
      },
    },
  },
};
